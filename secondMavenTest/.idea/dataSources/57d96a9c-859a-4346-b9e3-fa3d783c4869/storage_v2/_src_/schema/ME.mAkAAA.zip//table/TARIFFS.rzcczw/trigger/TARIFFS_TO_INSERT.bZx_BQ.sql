create trigger TARIFFS_TO_INSERT
  before insert
  on TARIFFS
  for each row
  begin
    select tariffs_sequence.nextval
    into :new.tariff_id
    from dual;
  end;
/

